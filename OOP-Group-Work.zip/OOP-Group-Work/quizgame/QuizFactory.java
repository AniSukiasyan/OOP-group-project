package quizgame;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class QuizFactory {
    private static final int QUIZ_SIZE = 100;
    private final Random random = new Random();

    public Quiz createOopQuiz() {
        Quiz quiz = new Quiz("Object-Oriented Programming Quiz");
        List<Question> questionPool = new ArrayList<>();

        addConceptQuestions(questionPool);
        addInheritanceQuestions(questionPool);
        addEncapsulationQuestions(questionPool);
        addPolymorphismQuestions(questionPool);
        addAbstractionQuestions(questionPool);
        addCodeCompletionQuestions(questionPool);
        addCodeOutputQuestions(questionPool);
        addNumberSystemQuestions(questionPool);

        questionPool = deduplicateByPrompt(questionPool);
        Collections.shuffle(questionPool, random);

        int limit = Math.min(QUIZ_SIZE, questionPool.size());
        for (int i = 0; i < limit; i++) {
            quiz.addQuestion(questionPool.get(i));
        }

        return quiz;
    }

    private void addConceptQuestions(List<Question> questions) {
        questions.add(new MultipleChoiceQuestion(
                "Which OOP principle allows one class to acquire the properties and behaviors of another class?",
                new String[]{"Encapsulation", "Inheritance", "Abstraction", "Composition"},
                'B',
                5
        ));
        questions.add(new FillInBlankQuestion(
                "Fill in the blank: Hiding internal data and allowing access only through methods is called ________.",
                5,
                "encapsulation"
        ));
        questions.add(new TrueFalseQuestion(
                "Polymorphism allows the same method name to behave differently based on the object.",
                true,
                5
        ));
        questions.add(new MultipleChoiceQuestion(
                "Which keyword is used in Java to create a subclass from a superclass?",
                new String[]{"implements", "this", "extends", "super"},
                'C',
                5
        ));
        questions.add(new FillInBlankQuestion(
                "Fill in the blank: A class that cannot be instantiated directly and is meant to be inherited is called an ________ class.",
                5,
                "abstract"
        ));
        questions.add(new TrueFalseQuestion(
                "A private field can be accessed directly from any other class.",
                false,
                5
        ));
        questions.add(new MultipleChoiceQuestion(
                "Which access modifier makes a field available only inside the same class?",
                new String[]{"public", "private", "protected", "static"},
                'B',
                5
        ));
        questions.add(new MultipleChoiceQuestion(
                "Which keyword refers to the current object in Java?",
                new String[]{"super", "class", "this", "self"},
                'C',
                5
        ));
        questions.add(new TrueFalseQuestion(
                "A constructor can have the same name as its class.",
                true,
                5
        ));
        questions.add(new TrueFalseQuestion(
                "Method overloading and method overriding are exactly the same thing.",
                false,
                5
        ));
        questions.add(new MultipleChoiceQuestion(
                "Which OOP principle focuses on exposing only essential behavior?",
                new String[]{"Inheritance", "Abstraction", "Recursion", "Iteration"},
                'B',
                5
        ));
        questions.add(new FillInBlankQuestion(
                "Fill in the blank: Creating objects from a class is called ________.",
                5,
                "instantiation"
        ));
        questions.add(new MultipleChoiceQuestion(
                "Which keyword is used to inherit from an interface in Java?",
                new String[]{"extends", "implements", "inherits", "instanceof"},
                'B',
                5
        ));
        questions.add(new MultipleChoiceQuestion(
                "Which of these is NOT one of the four main OOP pillars?",
                new String[]{"Encapsulation", "Abstraction", "Inheritance", "Compilation"},
                'D',
                5
        ));
        questions.add(new TrueFalseQuestion(
                "A class may contain both data members and methods.",
                true,
                5
        ));
        questions.add(new FillInBlankQuestion(
                "Fill in the blank: The ability to take many forms is called ________.",
                5,
                "polymorphism"
        ));
        questions.add(new MultipleChoiceQuestion(
                "Which method is automatically called when an object is created?",
                new String[]{"main", "constructor", "finalize", "equals"},
                'B',
                5
        ));
        questions.add(new TrueFalseQuestion(
                "An object is a blueprint, and a class is a real instance.",
                false,
                5
        ));
        questions.add(new FillInBlankQuestion(
                "Fill in the blank: Variables defined inside a class are often called ________ or attributes.",
                5,
                "fields",
                "data members"
        ));
        questions.add(new MultipleChoiceQuestion(
                "Which keyword prevents a method from being overridden?",
                new String[]{"static", "final", "const", "private"},
                'B',
                5
        ));
    }

    private void addInheritanceQuestions(List<Question> questions) {
        questions.add(new CodeCompletionQuestion(
                "Complete the missing Java keyword in this code:\n\n"
                        + "public class Student _____ Person {\n"
                        + "}\n\n"
                        + "Fill the blank with the missing code.",
                5,
                "extends"
        ));
        questions.add(new FillInBlankQuestion(
                "Fill in the blank: In inheritance, the class being inherited from is called the ________ class.",
                5,
                "superclass",
                "parent class",
                "base class"
        ));
        questions.add(new FillInBlankQuestion(
                "Fill in the blank: A class that inherits from another class is called a ________ class.",
                5,
                "subclass",
                "child class",
                "derived class"
        ));
        questions.add(new TrueFalseQuestion(
                "Java supports multiple inheritance of classes directly.",
                false,
                5
        ));
        questions.add(new MultipleChoiceQuestion(
                "Which keyword lets a subclass call a parent constructor?",
                new String[]{"this", "super", "base", "parent"},
                'B',
                5
        ));
        questions.add(new CodeCompletionQuestion(
                "Complete the code:\n\n"
                        + "class Dog extends Animal {\n"
                        + "    Dog() {\n"
                        + "        ________(\"Dog\");\n"
                        + "    }\n"
                        + "}",
                5,
                "super"
        ));
        questions.add(new TrueFalseQuestion(
                "A subclass inherits accessible methods and fields from its superclass.",
                true,
                5
        ));
        questions.add(new MultipleChoiceQuestion(
                "What is the default superclass of every Java class if none is specified?",
                new String[]{"Class", "Main", "Object", "Base"},
                'C',
                5
        ));
        questions.add(new FillInBlankQuestion(
                "Fill in the blank: Calling a method with the same signature in a subclass is called method ________.",
                5,
                "overriding"
        ));
        questions.add(new MultipleChoiceQuestion(
                "Which access level cannot be inherited outside its own class?",
                new String[]{"public", "protected", "private", "default"},
                'C',
                5
        ));
    }

    private void addEncapsulationQuestions(List<Question> questions) {
        questions.add(new CodeCompletionQuestion(
                "Complete the missing method call in this encapsulation example:\n\n"
                        + "Student s = new Student();\n"
                        + "s.__________(\"Ani\");\n\n"
                        + "Assume the setter method updates the student's name.",
                5,
                "setName"
        ));
        questions.add(new FillInBlankQuestion(
                "Fill in the blank: Methods like getAge() are called ________ and mutators.",
                5,
                "accessors",
                "getter methods",
                "getters"
        ));
        questions.add(new TrueFalseQuestion(
                "Encapsulation usually hides fields behind public methods.",
                true,
                5
        ));
        questions.add(new MultipleChoiceQuestion(
                "Which pair is most commonly used for encapsulation?",
                new String[]{"public fields and no methods", "private fields with getters and setters",
                        "abstract fields", "interface fields"},
                'B',
                5
        ));
        questions.add(new FillInBlankQuestion(
                "Fill in the blank: A method that returns a private field value is often called a ________.",
                5,
                "getter",
                "accessor"
        ));
        questions.add(new FillInBlankQuestion(
                "Fill in the blank: A method that changes a field value is often called a ________.",
                5,
                "setter",
                "mutator"
        ));
        questions.add(new TrueFalseQuestion(
                "Using private fields can help protect object state from invalid external changes.",
                true,
                5
        ));
        questions.add(new CodeCompletionQuestion(
                "Complete the missing access modifier:\n\n"
                        + "class BankAccount {\n"
                        + "    ________ double balance;\n"
                        + "}",
                5,
                "private"
        ));
        questions.add(new MultipleChoiceQuestion(
                "Which access modifier allows access from everywhere?",
                new String[]{"private", "default", "public", "protected"},
                'C',
                5
        ));
        questions.add(new FillInBlankQuestion(
                "Fill in the blank: Bundling data and the methods that operate on it into one unit is called ________.",
                5,
                "encapsulation"
        ));
    }

    private void addPolymorphismQuestions(List<Question> questions) {
        questions.add(new MultipleChoiceQuestion(
                "Which of the following is an example of runtime polymorphism?",
                new String[]{"Method overloading", "Method overriding", "Using variables", "Using loops"},
                'B',
                5
        ));
        questions.add(new TrueFalseQuestion(
                "A parent reference can point to a child object in Java.",
                true,
                5
        ));
        questions.add(new FillInBlankQuestion(
                "Fill in the blank: Defining multiple methods with the same name but different parameters is method ________.",
                5,
                "overloading"
        ));
        questions.add(new FillInBlankQuestion(
                "Fill in the blank: Changing inherited behavior in a subclass is method ________.",
                5,
                "overriding"
        ));
        questions.add(new MultipleChoiceQuestion(
                "Compile-time polymorphism is usually associated with:",
                new String[]{"Overloading", "Overriding", "Inheritance only", "Interfaces only"},
                'A',
                5
        ));
        questions.add(new MultipleChoiceQuestion(
                "Runtime polymorphism is usually achieved through:",
                new String[]{"Static variables", "Overriding", "Constructors", "Packages"},
                'B',
                5
        ));
        questions.add(new TrueFalseQuestion(
                "Polymorphism can reduce the need for large chains of if-else checks on object type.",
                true,
                5
        ));
        questions.add(new CodeCompletionQuestion(
                "Complete the code:\n\n"
                        + "Animal pet = new Dog();\n"
                        + "pet.__________();\n\n"
                        + "Assume Dog overrides this inherited behavior.",
                5,
                "makeSound",
                "speak"
        ));
        questions.add(new FillInBlankQuestion(
                "Fill in the blank: One interface can be implemented by many different ________.",
                5,
                "classes",
                "objects"
        ));
        questions.add(new TrueFalseQuestion(
                "Method overloading is resolved at compile time.",
                true,
                5
        ));
    }

    private void addAbstractionQuestions(List<Question> questions) {
        questions.add(new FillInBlankQuestion(
                "Fill in the blank: An abstract class may contain both abstract and ________ methods.",
                5,
                "concrete",
                "non-abstract"
        ));
        questions.add(new MultipleChoiceQuestion(
                "Which keyword declares an abstract method in Java?",
                new String[]{"virtual", "abstract", "override", "final"},
                'B',
                5
        ));
        questions.add(new TrueFalseQuestion(
                "An interface is one way to achieve abstraction in Java.",
                true,
                5
        ));
        questions.add(new FillInBlankQuestion(
                "Fill in the blank: A class with at least one abstract method must itself be declared ________.",
                5,
                "abstract"
        ));
        questions.add(new MultipleChoiceQuestion(
                "What is the main purpose of abstraction?",
                new String[]{"To duplicate code", "To hide unnecessary details", "To avoid classes", "To replace variables"},
                'B',
                5
        ));
        questions.add(new TrueFalseQuestion(
                "You can create an object directly from an abstract class.",
                false,
                5
        ));
        questions.add(new CodeCompletionQuestion(
                "Complete the code:\n\n"
                        + "public ________ class Shape {\n"
                        + "    public abstract double area();\n"
                        + "}",
                5,
                "abstract"
        ));
        questions.add(new FillInBlankQuestion(
                "Fill in the blank: In abstraction, we focus on what an object does, not how it is ________.",
                5,
                "implemented"
        ));
        questions.add(new MultipleChoiceQuestion(
                "Which construct cannot have object instances directly?",
                new String[]{"Concrete class", "Abstract class", "Array", "String"},
                'B',
                5
        ));
        questions.add(new TrueFalseQuestion(
                "Interfaces can define behavior contracts.",
                true,
                5
        ));
    }

    private void addCodeCompletionQuestions(List<Question> questions) {
        for (int i = 0; i < 10; i++) {
            int value = random.nextInt(41) + 10;
            questions.add(new CodeCompletionQuestion(
                    "Complete the missing return statement:\n\n"
                            + "public int getValue() {\n"
                            + "    ________ " + value + ";\n"
                            + "}",
                    5,
                    "return"
            ));
        }

        for (int i = 0; i < 10; i++) {
            String field = pick(new String[]{"name", "age", "salary", "id", "grade"});
            String type = field.equals("age") || field.equals("id") ? "int" : "String";
            questions.add(new CodeCompletionQuestion(
                    "Complete the setter method name:\n\n"
                            + "private " + type + " " + field + ";\n\n"
                            + "public void ________(" + type + " " + field + ") {\n"
                            + "    this." + field + " = " + field + ";\n"
                            + "}",
                    5,
                    "set" + capitalize(field)
            ));
        }
    }

    private void addCodeOutputQuestions(List<Question> questions) {
        for (int i = 0; i < 10; i++) {
            int a = random.nextInt(9) + 1;
            int b = random.nextInt(9) + 1;
            int result = a + b;
            questions.add(new FillInBlankQuestion(
                    "What is the output of this Java code?\n\n"
                            + "int a = " + a + ";\n"
                            + "int b = " + b + ";\n"
                            + "System.out.println(a + b);",
                    5,
                    String.valueOf(result)
            ));
        }

        for (int i = 0; i < 5; i++) {
            String left = pick(new String[]{"Hello", "Java", "OOP", "Quiz", "Code"});
            String right = pick(new String[]{"World", "Game", "Class", "Player", "Time"});
            String output = left + right;
            questions.add(new FillInBlankQuestion(
                    "What is the output of this Java code?\n\n"
                            + "String first = \"" + left + "\";\n"
                            + "String second = \"" + right + "\";\n"
                            + "System.out.println(first + second);",
                    5,
                    output
            ));
        }

        for (int i = 0; i < 5; i++) {
            int value = random.nextInt(20) + 1;
            int after = value + 1;
            questions.add(new FillInBlankQuestion(
                    "What is the output of this Java code?\n\n"
                            + "int x = " + value + ";\n"
                            + "x++;\n"
                            + "System.out.println(x);",
                    5,
                    String.valueOf(after)
            ));
        }

        for (int i = 0; i < 5; i++) {
            boolean flag = random.nextBoolean();
            questions.add(new FillInBlankQuestion(
                    "What is the output of this Java code?\n\n"
                            + "boolean flag = " + flag + ";\n"
                            + "System.out.println(!flag);",
                    5,
                    String.valueOf(!flag)
            ));
        }
    }

    private void addNumberSystemQuestions(List<Question> questions) {
        for (int i = 0; i < 8; i++) {
            int decimal = random.nextInt(61) + 4;
            questions.add(new FillInBlankQuestion(
                    "Convert the decimal number " + decimal + " to binary.",
                    5,
                    Integer.toBinaryString(decimal)
            ));
        }

        for (int i = 0; i < 8; i++) {
            int decimal = random.nextInt(121) + 8;
            questions.add(new FillInBlankQuestion(
                    "Convert the decimal number " + decimal + " to hexadecimal.",
                    5,
                    Integer.toHexString(decimal).toUpperCase(),
                    Integer.toHexString(decimal).toLowerCase()
            ));
        }

        for (int i = 0; i < 8; i++) {
            int decimal = random.nextInt(81) + 8;
            questions.add(new FillInBlankQuestion(
                    "Convert the decimal number " + decimal + " to octal.",
                    5,
                    Integer.toOctalString(decimal)
            ));
        }

        for (int i = 0; i < 8; i++) {
            int decimal = random.nextInt(121) + 10;
            String hex = Integer.toHexString(decimal).toUpperCase();
            questions.add(new FillInBlankQuestion(
                    "Convert the hexadecimal number " + hex + " to decimal.",
                    5,
                    String.valueOf(decimal)
            ));
        }

        for (int i = 0; i < 8; i++) {
            int decimal = random.nextInt(61) + 5;
            String binary = Integer.toBinaryString(decimal);
            questions.add(new FillInBlankQuestion(
                    "Convert the binary number " + binary + " to decimal.",
                    5,
                    String.valueOf(decimal)
            ));
        }

        for (int i = 0; i < 8; i++) {
            int decimal = random.nextInt(81) + 8;
            String octal = Integer.toOctalString(decimal);
            questions.add(new FillInBlankQuestion(
                    "Convert the octal number " + octal + " to decimal.",
                    5,
                    String.valueOf(decimal)
            ));
        }
    }

    private String pick(String[] values) {
        return values[random.nextInt(values.length)];
    }

    private String capitalize(String value) {
        return value.substring(0, 1).toUpperCase() + value.substring(1);
    }

    private List<Question> deduplicateByPrompt(List<Question> questions) {
        List<Question> uniqueQuestions = new ArrayList<>();
        Set<String> seenPrompts = new LinkedHashSet<>();

        for (Question question : questions) {
            if (seenPrompts.add(question.getPrompt())) {
                uniqueQuestions.add(question);
            }
        }

        return uniqueQuestions;
    }
}
